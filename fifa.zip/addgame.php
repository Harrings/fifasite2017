<?php
ob_start(); //from stack overflow
include 'pass.php';
error_reporting(E_ALL);
ini_set('display_errors','On');
session_start();

$error=0;
$mysqli = new mysqli("oniddb.cws.oregonstate.edu", "harrings-db", $pass, "harrings-db");
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}
if (($_POST["winner"]==null))
{
	echo "Error to add a game it must have a name click <a href=\"video.php\">here</a> to return to inventory managment";
}
else
{
	$winner=$_POST["winner"];
	$loser=$_POST["loser"];
	$goalfw=$_POST["goalfw"];
	$goalfl=$_POST["goalfl"];
	$gs1=$_POST["Goal1"];
	$gs2=$_POST["Goal2"];
	$gs3=$_POST["Goal3"];
	$gs4=$_POST["Goal4"];
	$gs5=$_POST["Goal5"];
	$gs6=$_POST["Goal6"];
	$gs7=$_POST["Goal7"];
	$gs8=$_POST["Goal8"];
	if (!($stmt = $mysqli->prepare("INSERT INTO Games(winner, loser, goalfw, goalfl) VALUES (?,?,?,?)"))) {
		 echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
		 $error=1;
	}
	if (!$stmt->bind_param("ssii", $winner, $loser, $goalfw,$goalfl)) {
		echo "Binding parameters failed: (" . $stmt->errno . ") " . $stmt->error;
		$error=1;
	}
	if (!$stmt->execute()) {
		//echo "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
		$error=1;
	}
	$stmt->close();
	if ($gs1!=null)
	{
		if (!($stmt = $mysqli->prepare("UPDATE GoalScorer SET goals=goals+1 WHERE player=?"))) {
		 echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
		}
		if (!$stmt->bind_param("s", $gs1)) {
		echo "Binding parameters failed: (" . $stmt->errno . ") " . $stmt->error;
		}
		if (!$stmt->execute()) {
		echo "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
		}
		$stmt->close();
	}
	if ($gs2!=null)
	{
		if (!($stmt = $mysqli->prepare("UPDATE GoalScorer SET goals=goals+1 WHERE player=?"))) {
		 echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
		}
		if (!$stmt->bind_param("s", $gs2)) {
		echo "Binding parameters failed: (" . $stmt->errno . ") " . $stmt->error;
		}
		if (!$stmt->execute()) {
		echo "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
		}
		$stmt->close();
	}
	if ($gs3!=null)
	{
		if (!($stmt = $mysqli->prepare("UPDATE GoalScorer SET goals=goals+1 WHERE player=?"))) {
		 echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
		}
		if (!$stmt->bind_param("s", $gs3)) {
		echo "Binding parameters failed: (" . $stmt->errno . ") " . $stmt->error;
		}
		if (!$stmt->execute()) {
		echo "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
		}
		$stmt->close();
	}
	if ($gs4!=null)
	{
		if (!($stmt = $mysqli->prepare("UPDATE GoalScorer SET goals=goals+1 WHERE player=?"))) {
		 echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
		}
		if (!$stmt->bind_param("s", $gs4)) {
		echo "Binding parameters failed: (" . $stmt->errno . ") " . $stmt->error;
		}
		if (!$stmt->execute()) {
		echo "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
		}
		$stmt->close();
	}
	if ($gs5!=null)
	{
		if (!($stmt = $mysqli->prepare("UPDATE GoalScorer SET goals=goals+1 WHERE player=?"))) {
		 echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
		}
		if (!$stmt->bind_param("s", $gs5)) {
		echo "Binding parameters failed: (" . $stmt->errno . ") " . $stmt->error;
		}
		if (!$stmt->execute()) {
		echo "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
		}
		$stmt->close();
	}
	if ($gs6!=null)
	{
		if (!($stmt = $mysqli->prepare("UPDATE GoalScorer SET goals=goals+1 WHERE player=?"))) {
		 echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
		}
		if (!$stmt->bind_param("s", $gs6)) {
		echo "Binding parameters failed: (" . $stmt->errno . ") " . $stmt->error;
		}
		if (!$stmt->execute()) {
		echo "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
		}
		$stmt->close();
	}
	if ($gs7!=null)
	{
		if (!($stmt = $mysqli->prepare("UPDATE GoalScorer SET goals=goals+1 WHERE player=?"))) {
		 echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
		}
		if (!$stmt->bind_param("s", $gs7)) {
		echo "Binding parameters failed: (" . $stmt->errno . ") " . $stmt->error;
		}
		if (!$stmt->execute()) {
		echo "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
		}
		$stmt->close();
	}
	if ($gs8!=null)
	{
		if (!($stmt = $mysqli->prepare("UPDATE GoalScorer SET goals=goals+1 WHERE player=?"))) {
		 echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
		}
		if (!$stmt->bind_param("s", $gs8)) {
		echo "Binding parameters failed: (" . $stmt->errno . ") " . $stmt->error;
		}
		if (!$stmt->execute()) {
		echo "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
		}
		$stmt->close();
	}
	$error=0;
	if ($error==0)
	{
		header("Location: video.php", true);
	}
	else
	{
		echo "Error there is already a video with the same name in the inventory click <a href=\"video.php\">here</a> to return to inventory managment";
	}
}
?>
