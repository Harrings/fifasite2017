<?php
$pass="minstFy7WEjCWSCr";
?>