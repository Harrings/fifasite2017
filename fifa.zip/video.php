<?php
ob_start(); //from stack overflow
include 'pass.php';
error_reporting(E_ALL);
ini_set('display_errors','On');
session_start();
$mysqli = new mysqli("oniddb.cws.oregonstate.edu", "harrings-db", $pass, "harrings-db");
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>FifaTrack</title>
</head>
<body>
<h2>Standings</h2>
<table border="1">
<thead> 
<tr>
    <th>Name</th> 
    <th>Wins</th> 
    <th>Losses</th> 
	<th>Goals for</th> 
    <th>Goals Allowed</th> 
</tr> 
</thead>
<tbody>
<?php
//if (!isset($_SESSION["sort"])||($_SESSION["sort"]=="All"))
//{
	if (!$stmt = $mysqli->query("SELECT Count(winner) as win, Sum(goalfw) as g1f, Sum(goalfl) as g1a FROM Games where winner='Sean'")) {
		echo "Query Failed!: (" . $mysqli->errno . ") ". $mysqli->error;
	}
	$row = mysqli_fetch_array($stmt);	
	$goalsfor=$row['g1f'];
	$goalsagainst=$row['g1a'];
	echo "<tr>" ;
	echo "<td>Sean </td>";
	echo "<td>" . $row['win'] . "</td>";
	if (!$stmt = $mysqli->query("SELECT Count(loser) as loss, Sum(goalfw) as g2a, Sum(goalfl) as g2f FROM Games where loser='Sean'")) {
		echo "Query Failed!: (" . $mysqli->errno . ") ". $mysqli->error;
	}
	$row = mysqli_fetch_array($stmt);
	$totalfor=$goalsfor+$row['g2f'];
	$totalagainst=$goalsagainst+$row['g2a'];
	echo "<td>" . $row['loss'] . "</td>";
	echo "<td>" . $totalfor  . "</td>";
	echo "<td>" . $totalagainst . "</td>";
	echo "</tr>" ;
	if (!$stmt = $mysqli->query("SELECT Count(winner) as win, Sum(goalfw) as g1f, Sum(goalfl) as g1a FROM Games where winner='Will'")) {
		echo "Query Failed!: (" . $mysqli->errno . ") ". $mysqli->error;
	}
	$row = mysqli_fetch_array($stmt);	
	$goalsfor=$row['g1f'];
	$goalsagainst=$row['g1a'];
	echo "<tr>" ;
	echo "<td>Will </td>";
	echo "<td>" . $row['win'] . "</td>";
	if (!$stmt = $mysqli->query("SELECT Count(loser) as loss, Sum(goalfw) as g2a, Sum(goalfl) as g2f FROM Games where loser='Will'")) {
		echo "Query Failed!: (" . $mysqli->errno . ") ". $mysqli->error;
	}
	$row = mysqli_fetch_array($stmt);
	$totalfor=$goalsfor+$row['g2f'];
	$totalagainst=$goalsagainst+$row['g2a'];
	echo "<td>" . $row['loss'] . "</td>";
	echo "<td>" . $totalfor  . "</td>";
	echo "<td>" . $totalagainst . "</td>";
	echo "</tr>" ;
	if (!$stmt = $mysqli->query("SELECT Count(winner) as win, Sum(goalfw) as g1f, Sum(goalfl) as g1a FROM Games where winner='Clint'")) {
		echo "Query Failed!: (" . $mysqli->errno . ") ". $mysqli->error;
	}
	$row = mysqli_fetch_array($stmt);	
	$goalsfor=$row['g1f'];
	$goalsagainst=$row['g1a'];
	echo "<tr>" ;
	echo "<td>Clint </td>";
	echo "<td>" . $row['win'] . "</td>";
	if (!$stmt = $mysqli->query("SELECT Count(loser) as loss, Sum(goalfw) as g2a, Sum(goalfl) as g2f FROM Games where loser='Clint'")) {
		echo "Query Failed!: (" . $mysqli->errno . ") ". $mysqli->error;
	}
	$row = mysqli_fetch_array($stmt);
	$totalfor=$goalsfor+$row['g2f'];
	$totalagainst=$goalsagainst+$row['g2a'];
	echo "<td>" . $row['loss'] . "</td>";
	echo "<td>" . $totalfor  . "</td>";
	echo "<td>" . $totalagainst . "</td>";
	echo "</tr>" ;
	
?>
	</tbody>
</table>
<h2>Goal Count</h2>
<table border="1">
<thead> 
<tr>
    <th>Name</th> 
    <th>Goals</th> 
</tr> 
</thead>
<tbody>
<?php
//if (!isset($_SESSION["sort"])||($_SESSION["sort"]=="All"))
//{
	if (!$stmt = $mysqli->query("SELECT player, goals FROM GoalScorer order by Goals DESC")) {
		echo "Query Failed!: (" . $mysqli->errno . ") ". $mysqli->error;
	}
	while($row = mysqli_fetch_array($stmt))	
{
	echo "<tr>" ;
	echo "<td>" . $row['player'] . "</td>";
	echo "<td>" . $row['goals'] . "</td>";
	echo "</tr>";
}
	
	
?>
</tbody>
</table>

<h2>Add Game</h2>
<form action="addgame.php" method="post">
		<p>Winner</p>
		<select name="winner">
		<option value=null>None</option>
		<option value="Sean">Sean</option>
		<option value="Clint">Clint</option>
		<option value="Will">Will</option>
		</select>
		<p>Goals Scored: <input type="number" name="goalfw" /></p>
		<p>Loser</p>
		<select name="loser">
		<option value=null>None</option>
		<option value="Sean">Sean</option>
		<option value="Clint">Clint</option>
		<option value="Will">Will</option>
		</select>
		<p>Goals Scored: <input type="number" name="goalfl" /></p>
		<br><br>
		<p>GoalScorer1</p>
		<select name="Goal1">
		<option value=null>None</option>
		<option value="Alaba">Alaba</option>
		<option value="Neymar">Neymar</option>
		<option value="Suarez">Suarez</option>
		<option value="De Bruyne">De Bruyne</option>
		<option value="Robben">Robben</option>
		<option value="Reus">Reus</option>
		<option value="Pogba">Pogba</option>
		<option value="Hulk">Hulk</option>
		<option value="Hazard">Hazard</option>
		<option value="Vidal">Vidal</option>
		<option value="Sturridge">Sturridge</option>
		<option value="Lewandowski">Lewandowski</option>
		<option value="James">James</option>
		<option value="Messi">Messi</option>
		<option value="Di Maria">Di Maria</option>
		<option value="Naingolem">Naingolem</option>
		<option value="Ibra">Ibra</option>
		<option value="Bale">Bale</option>
		<option value="Tevez">Tevez</option>
		<option value="Ronaldo">Ronaldo</option>
		<option value="Other">Other</option>
		</select>
		<p>GoalScorer2</p>
			<select name="Goal2">
		<option value=null>None</option>
		<option value="Alaba">Alaba</option>
		<option value="Neymar">Neymar</option>
		<option value="Suarez">Suarez</option>
		<option value="De Bruyne">De Bruyne</option>
		<option value="Robben">Robben</option>
		<option value="Reus">Reus</option>
		<option value="Pogba">Pogba</option>
		<option value="Hulk">Hulk</option>
		<option value="Hazard">Hazard</option>
		<option value="Vidal">Vidal</option>
		<option value="Sturridge">Sturridge</option>
		<option value="Lewandowski">Lewandowski</option>
		<option value="James">James</option>
		<option value="Messi">Messi</option>
		<option value="Di Maria">Di Maria</option>
		<option value="Naingolem">Naingolem</option>
		<option value="Ibra">Ibra</option>
		<option value="Bale">Bale</option>
		<option value="Tevez">Tevez</option>
		<option value="Ronaldo">Ronaldo</option>
		<option value="Other">Other</option>
		</select>
		<p>GoalScorer3</p>
		<select name="Goal3">
		<option value=null>None</option>
		<option value="Alaba">Alaba</option>
		<option value="Neymar">Neymar</option>
		<option value="Suarez">Suarez</option>
		<option value="De Bruyne">De Bruyne</option>
		<option value="Robben">Robben</option>
		<option value="Reus">Reus</option>
		<option value="Pogba">Pogba</option>
		<option value="Hulk">Hulk</option>
		<option value="Hazard">Hazard</option>
		<option value="Vidal">Vidal</option>
		<option value="Sturridge">Sturridge</option>
		<option value="Lewandowski">Lewandowski</option>
		<option value="James">James</option>
		<option value="Messi">Messi</option>
		<option value="Di Maria">Di Maria</option>
		<option value="Naingolem">Naingolem</option>
		<option value="Ibra">Ibra</option>
		<option value="Bale">Bale</option>
		<option value="Tevez">Tevez</option>
		<option value="Ronaldo">Ronaldo</option>
		<option value="Other">Other</option>
		</select>
		<p>GoalScorer4</p>
			<select name="Goal4"><p>GoalScorer</p>
			<option value=null>None</option>
		<option value="Alaba">Alaba</option>
		<option value="Neymar">Neymar</option>
		<option value="Suarez">Suarez</option>
		<option value="De Bruyne">De Bruyne</option>
		<option value="Robben">Robben</option>
		<option value="Reus">Reus</option>
		<option value="Pogba">Pogba</option>
		<option value="Hulk">Hulk</option>
		<option value="Hazard">Hazard</option>
		<option value="Vidal">Vidal</option>
		<option value="Sturridge">Sturridge</option>
		<option value="Lewandowski">Lewandowski</option>
		<option value="James">James</option>
		<option value="Messi">Messi</option>
		<option value="Di Maria">Di Maria</option>
		<option value="Naingolem">Naingolem</option>
		<option value="Ibra">Ibra</option>
		<option value="Bale">Bale</option>
		<option value="Tevez">Tevez</option>
		<option value="Ronaldo">Ronaldo</option>
		<option value="Other">Other</option>
		</select>
		<p>GoalScorer5</p>
		<select name="Goal5"><p>GoalScorer</p>
		<option value=null>None</option>
		<option value="Alaba">Alaba</option>
		<option value="Neymar">Neymar</option>
		<option value="Suarez">Suarez</option>
		<option value="De Bruyne">De Bruyne</option>
		<option value="Robben">Robben</option>
		<option value="Reus">Reus</option>
		<option value="Pogba">Pogba</option>
		<option value="Hulk">Hulk</option>
		<option value="Hazard">Hazard</option>
		<option value="Vidal">Vidal</option>
		<option value="Sturridge">Sturridge</option>
		<option value="Lewandowski">Lewandowski</option>
		<option value="James">James</option>
		<option value="Messi">Messi</option>
		<option value="Di Maria">Di Maria</option>
		<option value="Naingolem">Naingolem</option>
		<option value="Ibra">Ibra</option>
		<option value="Bale">Bale</option>
		<option value="Tevez">Tevez</option>
		<option value="Ronaldo">Ronaldo</option>
		<option value="Other">Other</option>
		</select>
		<p>GoalScorer6</p>
			<select name="Goal6"><p>GoalScorer</p>
			<option value=null>None</option>
		<option value="Alaba">Alaba</option>
		<option value="Neymar">Neymar</option>
		<option value="Suarez">Suarez</option>
		<option value="De Bruyne">De Bruyne</option>
		<option value="Robben">Robben</option>
		<option value="Reus">Reus</option>
		<option value="Pogba">Pogba</option>
		<option value="Hulk">Hulk</option>
		<option value="Hazard">Hazard</option>
		<option value="Vidal">Vidal</option>
		<option value="Sturridge">Sturridge</option>
		<option value="Lewandowski">Lewandowski</option>
		<option value="James">James</option>
		<option value="Messi">Messi</option>
		<option value="Di Maria">Di Maria</option>
		<option value="Naingolem">Naingolem</option>
		<option value="Ibra">Ibra</option>
		<option value="Bale">Bale</option>
		<option value="Tevez">Tevez</option>
		<option value="Ronaldo">Ronaldo</option>
		<option value="Other">Other</option>
		</select>
		<p>GoalScorer7</p>
		<select name="Goal7"><p>GoalScorer</p>
		<option value=null>None</option>
		<option value="Alaba">Alaba</option>
		<option value="Neymar">Neymar</option>
		<option value="Suarez">Suarez</option>
		<option value="De Bruyne">De Bruyne</option>
		<option value="Robben">Robben</option>
		<option value="Reus">Reus</option>
		<option value="Pogba">Pogba</option>
		<option value="Hulk">Hulk</option>
		<option value="Hazard">Hazard</option>
		<option value="Vidal">Vidal</option>
		<option value="Sturridge">Sturridge</option>
		<option value="Lewandowski">Lewandowski</option>
		<option value="James">James</option>
		<option value="Messi">Messi</option>
		<option value="Di Maria">Di Maria</option>
		<option value="Naingolem">Naingolem</option>
		<option value="Ibra">Ibra</option>
		<option value="Bale">Bale</option>
		<option value="Tevez">Tevez</option>
		<option value="Ronaldo">Ronaldo</option>
		<option value="Other">Other</option>
		</select>
		<p>GoalScorer8</p>
			<select name="Goal8"><p>GoalScorer</p>
			<option value=null>None</option>
		<option value="Alaba">Alaba</option>
		<option value="Neymar">Neymar</option>
		<option value="Suarez">Suarez</option>
		<option value="De Bruyne">De Bruyne</option>
		<option value="Robben">Robben</option>
		<option value="Reus">Reus</option>
		<option value="Pogba">Pogba</option>
		<option value="Hulk">Hulk</option>
		<option value="Hazard">Hazard</option>
		<option value="Vidal">Vidal</option>
		<option value="Sturridge">Sturridge</option>
		<option value="Lewandowski">Lewandowski</option>
		<option value="James">James</option>
		<option value="Messi">Messi</option>
		<option value="Di Maria">Di Maria</option>
		<option value="Naingolem">Naingolem</option>
		<option value="Ibra">Ibra</option>
		<option value="Bale">Bale</option>
		<option value="Tevez">Tevez</option>
		<option value="Ronaldo">Ronaldo</option>
		<option value="Other">Other</option>
		</select>
		<br><br>
		<input type="submit" value="Submit">
</form>

<?php
//if (!isset($_SESSION["sort"])||($_SESSION["sort"]=="All"))
//{
	if (!$stmt = $mysqli->query("SELECT id, winner, goalfw, loser, goalfl FROM Games")) {
		echo "Query Failed!: (" . $mysqli->errno . ") ". $mysqli->error;
	}
//}
/*
else
{
	if (!$stmt = $mysqli->prepare("SELECT name, category, length FROM VSTORE WHERE category= ?")) {
		echo "Prepare Failed!: (" . $mysqli->errno . ") ". $mysqli->error;
	}
	$sorter=$_SESSION["sort"];
	if (!$stmt->bind_param("s", $sorter)) {
    echo "Binding parameters failed: (" . $stmt->errno . ") " . $stmt->error;
	}
	
	$sorter=$_SESSION["sort"];
	if (!$stmt = $mysqli->query("SELECT name, category, length, rented FROM VSTORE WHERE category='$sorter'")) {
		echo "Query Failed!: (" . $mysqli->errno . ") ". $mysqli->error;
	}
	echo "Currently showing only $sorter films";
	$_SESSION["sort"]="All";
}
*/

/*if (!$stmt->execute()) {
echo "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
} */
?>

<table border="1">
<thead> 
<tr>
    <th>Winner</th> 
    <th>Goal Scored</th> 
    <th>Loser</th> 
    <th>Goal Scored</th> 
    <th>Delete</th>
</tr> 
</thead>
<tbody>
<?php
//$cats=array();

while($row = mysqli_fetch_array($stmt))	
{
	echo "<tr>" ;
	echo "<td>" . $row['winner'] . "</td>";
	echo "<td>" . $row['goalfw'] . "</td>";
	echo "<td>" . $row['loser'] . "</td>";
	echo "<td>" . $row['goalfl'] . "</td>";
	echo "<td><form method=\"POST\" action=\"delete.php\">";
	echo "<input type=\"hidden\" name=\"nameid\" value=\"".$row['id']."\">";
	echo "<input type=\"submit\" value=\"delete\">";
	echo "</form> </td>";
	echo "</tr>";
}
/*
if (!$stmt = $mysqli->query("SELECT category FROM VSTORE")) {
		echo "Query Failed!: (" . $mysqli->errno . ") ". $mysqli->error;
	}
while($row = mysqli_fetch_array($stmt))	
{
	if ((!(in_array($row['category'], $cats)))&&($row['category']!=null))
	{
		array_push($cats,$row['category']);
	}
}

	
?>

<form action="filter.php" method="POST">
<div align="center">
<select name="sort">
<option value="All">All Movies</option>
<?php
$x=count($cats);
for ($i=0;$i<$x; $i++)
{
	echo "<option value=$cats[$i]>$cats[$i]</option>";
}
?>
</select>
</div>
<input type="submit" value="Filter">
</form>
<form method="POST" action="deleteall.php">
<input type="hidden" name="deletekey" value="xjy">
<input type="submit" value="delete all">
</form>
*/
?>
</tbody>
</table>
	</body>
</html>	
	

	
